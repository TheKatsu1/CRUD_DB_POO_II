﻿using AcademicoFOA2023.Models;
using Microsoft.EntityFrameworkCore;

namespace AcademicoFOA2023.Data
{
    public class AcademicoContext:DbContext
    {
        public AcademicoContext(DbContextOptions<AcademicoContext> options) : base(options) { }

        public DbSet<Instituicao> Instituicoes { get; set;}

    }
}
